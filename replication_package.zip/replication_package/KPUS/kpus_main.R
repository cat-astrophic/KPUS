# Running this script replicates the associated project

# Installing packages to ensure replication success

install.packages('dplyr', 'Synth', 'ggrepel', 'ggplot2', 'patchwork', 'modelsummary', 'xgboost', 'imputation')

# Specifying the project directory -- update this accordingly !!

direc <- 'D:/KPUS/'

# Running the scripts

source(paste0(direc, 'kpus.R'))
source(paste0(direc, 'kpus_boosted.R'))

